Install the libraries mentioned below to run the program. Copy and paste the below code to import the libraries as is.

import cv2
import time
import math
import numpy as np
import heapq

The inputs I gave for the robot were.

Initial position: 0,0
Final position: 400,20

The time taken for the code on average was 35 minutes.
